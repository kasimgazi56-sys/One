import 'package:flutter/material.dart';

void main() => runApp(const OneRideDriverApp());

const yellow = Color(0xFFFFC400);
const black = Color(0xFF151515);

class OneRideDriverApp extends StatelessWidget {
  const OneRideDriverApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'ONE RIDE Driver', debugShowCheckedModeBanner: false,
    theme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: yellow), scaffoldBackgroundColor: const Color(0xFFF6F6F6)),
    home: const DriverHome(),
  );
}

class DriverHome extends StatefulWidget {
  const DriverHome({super.key});
  @override
  State<DriverHome> createState() => _DriverHomeState();
}

class _DriverHomeState extends State<DriverHome> {
  bool online = false;
  bool accepted = false;
  bool completed = false;
  int earnings = 0;

  void message(String text) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(backgroundColor: black, foregroundColor: Colors.white,
      title: const Row(children: [Icon(Icons.two_wheeler, color: yellow), SizedBox(width: 9), Text('ONE RIDE DRIVER', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: .7))]),
      actions: [IconButton(onPressed: () => message('Driver help will be connected in the production version.'), icon: const Icon(Icons.help_outline))],
    ),
    body: ListView(padding: const EdgeInsets.all(18), children: [
      Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: black, borderRadius: BorderRadius.circular(20)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Welcome, Driver!', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 5), const Text('Aligarh, Uttar Pradesh', style: TextStyle(color: Colors.white70)),
        const SizedBox(height: 20),
        Row(children: [const Expanded(child: Text('Go online to receive ride requests', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600))), Switch(value: online, activeColor: yellow, onChanged: (v) => setState(() { online = v; if (!v) { accepted = false; completed = false; } }))]),
        Text(online ? 'You are ONLINE (demo mode)' : 'You are OFFLINE', style: TextStyle(color: online ? yellow : Colors.white70, fontWeight: FontWeight.bold)),
      ])),
      const SizedBox(height: 16),
      Row(children: [Expanded(child: _stat('Today’s earnings', '₹$earnings', Icons.currency_rupee)), const SizedBox(width: 10), Expanded(child: _stat('Completed rides', completed ? '1' : '0', Icons.check_circle_outline))]),
      const SizedBox(height: 22),
      const Text('Ride requests', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
      const SizedBox(height: 10),
      if (!online) _empty('You are offline', 'Turn on the switch above to see a sample request.')
      else if (completed) _empty('No new requests', 'You completed the demo ride. New requests will appear here in the live app.')
      else if (accepted) _rideInProgress(context)
      else _requestCard(context),
      const SizedBox(height: 18),
      const Text('Driver checklist', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const _check('Valid driving licence'), const _check('Vehicle registration and insurance'), const _check('Helmet and safety equipment'), const _check('Profile and documents verified'),
      const SizedBox(height: 10),
      const Text('Demo only: no real customers, dispatch, GPS or payments are connected.', style: TextStyle(color: Colors.black54, fontSize: 12)),
    ]),
  );

  Widget _stat(String label, String value, IconData icon) => Container(padding: const EdgeInsets.all(15), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(icon), const SizedBox(height: 8), Text(value, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900)), Text(label, style: const TextStyle(color: Colors.black54, fontSize: 12))]));
  Widget _empty(String title, String body) => Container(padding: const EdgeInsets.all(25), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)), child: Column(children: [const Icon(Icons.motorcycle, size: 42, color: Colors.black38), const SizedBox(height: 8), Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17)), Text(body, textAlign: TextAlign.center, style: const TextStyle(color: Colors.black54))]));
  Widget _requestCard(BuildContext context) => Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), border: Border.all(color: yellow, width: 1.5)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Row(children: [const Expanded(child: Text('New demo ride request', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),), Chip(backgroundColor: const Color(0xFFFFF2BF), label: const Text('DEMO'))]),
    const Divider(), const _routeRow(Icons.my_location, 'Pickup', 'Aligarh Railway Station'), const SizedBox(height: 12), const _routeRow(Icons.location_on, 'Drop', 'AMU Main Gate'), const Divider(),
    const Row(children: [Icon(Icons.currency_rupee), Text('  ₹60 demo fare estimate', style: TextStyle(fontWeight: FontWeight.bold))]), const SizedBox(height: 14),
    Row(children: [Expanded(child: OutlinedButton(onPressed: () => setState(() { completed = true; }), child: const Text('REJECT'))), const SizedBox(width: 10), Expanded(child: FilledButton(style: FilledButton.styleFrom(backgroundColor: yellow, foregroundColor: black), onPressed: () => setState(() => accepted = true), child: const Text('ACCEPT')))]),
  ]));
  Widget _rideInProgress(BuildContext context) => Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('Ride accepted', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18)), const SizedBox(height: 8), const Text('Pickup: Aligarh Railway Station'), const Text('Drop: AMU Main Gate'), const SizedBox(height: 14), SizedBox(width: double.infinity, child: FilledButton(style: FilledButton.styleFrom(backgroundColor: yellow, foregroundColor: black), onPressed: () => setState(() { completed = true; earnings += 60; accepted = false; }), child: const Text('COMPLETE DEMO RIDE')))]));
}

class _routeRow extends StatelessWidget {
  final IconData icon; final String label; final String place;
  const _routeRow(this.icon, this.label, this.place);
  @override
  Widget build(BuildContext context) => Row(children: [Icon(icon, color: label == 'Pickup' ? Colors.green : Colors.red), const SizedBox(width: 10), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(label, style: const TextStyle(color: Colors.black54, fontSize: 12)), Text(place, style: const TextStyle(fontWeight: FontWeight.bold))]))]);
}
class _check extends StatelessWidget {
  final String text; const _check(this.text);
  @override
  Widget build(BuildContext context) => CheckboxListTile(value: false, onChanged: null, dense: true, contentPadding: EdgeInsets.zero, controlAffinity: ListTileControlAffinity.leading, title: Text(text, style: const TextStyle(fontSize: 14)));
}
