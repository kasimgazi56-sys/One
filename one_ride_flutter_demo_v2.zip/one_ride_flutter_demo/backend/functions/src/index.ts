import { onCall, HttpsError } from "firebase-functions/v2/https";
import { initializeApp } from "firebase-admin/app";
import { FieldValue, getFirestore } from "firebase-admin/firestore";

initializeApp();
const db = getFirestore();

// Creates a ride request. Fare calculation and payment must be validated
// server-side before production use; this starter deliberately accepts a
// server-provided quote only as a placeholder and is not production-ready.
export const createRideRequest = onCall(async (request) => {
  if (!request.auth) throw new HttpsError("unauthenticated", "Sign in first.");
  const { pickup, drop, quotedFare } = request.data ?? {};
  if (typeof pickup !== "string" || pickup.trim().length < 3 ||
      typeof drop !== "string" || drop.trim().length < 3 ||
      typeof quotedFare !== "number" || quotedFare <= 0) {
    throw new HttpsError("invalid-argument", "Valid pickup, drop and fare are required.");
  }
  const ride = {
    passengerId: request.auth.uid,
    driverId: null,
    pickup: pickup.trim(),
    drop: drop.trim(),
    quotedFare,
    status: "requested",
    city: "Aligarh",
    createdAt: FieldValue.serverTimestamp(),
    updatedAt: FieldValue.serverTimestamp(),
  };
  const ref = await db.collection("rides").add(ride);
  return { rideId: ref.id, status: "requested" };
});

// Driver acceptance is transaction-protected so only one driver can claim a ride.
export const acceptRide = onCall(async (request) => {
  if (!request.auth) throw new HttpsError("unauthenticated", "Sign in first.");
  const { rideId } = request.data ?? {};
  if (typeof rideId !== "string" || !rideId) throw new HttpsError("invalid-argument", "rideId is required.");
  const driverRef = db.collection("drivers").doc(request.auth.uid);
  const rideRef = db.collection("rides").doc(rideId);
  await db.runTransaction(async (tx) => {
    const [driverSnap, rideSnap] = await Promise.all([tx.get(driverRef), tx.get(rideRef)]);
    if (!driverSnap.exists || driverSnap.data()?.verified !== true || driverSnap.data()?.active !== true) {
      throw new HttpsError("permission-denied", "Verified active driver profile required.");
    }
    if (!rideSnap.exists || rideSnap.data()?.status !== "requested" || rideSnap.data()?.driverId) {
      throw new HttpsError("failed-precondition", "Ride is no longer available.");
    }
    tx.update(rideRef, { driverId: request.auth!.uid, status: "accepted", updatedAt: FieldValue.serverTimestamp() });
  });
  return { rideId, status: "accepted" };
});
