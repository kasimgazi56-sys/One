# ONE RIDE — Customer + Driver Flutter demo

## Run the customer demo
```bash
flutter pub get
flutter run -t lib/main.dart
```

## Run the driver demo
```bash
flutter run -t lib/driver_main.dart
```

The driver demo includes online/offline toggle, a sample ride request, accept/reject, ride completion and demo earnings. The customer and driver demos are separate app entrypoints in the same Flutter project.

## Firebase/backend starter
- `backend/firestore/firestore.rules`: restrictive starter rules.
- `backend/functions`: TypeScript callable-function starter for ride creation and atomic driver acceptance.
- Flutter dependencies for Firebase Core, Auth and Firestore are listed in `pubspec.yaml`.

To connect Firebase: create a Firebase project, register separate Android and iOS app IDs, install FlutterFire CLI, run `flutterfire configure`, initialize Firebase in each entrypoint using the generated `firebase_options.dart`, then implement authentication and Firestore repositories. Configure Functions with Firebase CLI and deploy only after reviewing rules, identity checks, App Check, abuse controls and pricing logic.

## Important: demo, not a live ride service
This package is not production-ready. No real GPS/maps, driver dispatch, phone OTP, payment collection, notifications or admin portal are wired to the UI. The fare is placeholder data. Cloud Functions are starter examples and require security review, tests and additional lifecycle/authorization logic before deployment. Never use the demo to dispatch real rides or collect money.

Before public launch, verify applicable Uttar Pradesh/Aligarh bike-taxi permissions and transport requirements, driver/vehicle documents, insurance, safety and emergency workflows, privacy policy, terms, data retention and app-store requirements.
