# ONE RIDE — Aligarh Flutter demo

This project contains a customer demo app and a separate driver demo entry point.

## Build Android APKs from GitHub on an Android phone
1. Create a **public or private** GitHub repository named `one-ride`.
2. Extract this ZIP on your phone using the Files app.
3. In the GitHub repository, choose **Add file → Upload files** and upload the *contents* of the extracted `one_ride_flutter_demo` folder (including the hidden `.github` folder and its workflow file). Commit to `main`.
4. Open the repository's **Actions** tab. Select **Build ONE RIDE APKs** and wait for the run to finish green.
5. Open the completed workflow run and download the `one-ride-android-apks` artifact. Extract the artifact ZIP; it contains the customer and driver APKs.

## Local build
Install Flutter SDK and run `flutter pub get`, then:
- Customer: `flutter build apk --release --target lib/main.dart`
- Driver: `flutter build apk --release --target lib/driver_main.dart`

## Demo limitations
The customer fare is a placeholder estimate and the driver request is a sample. No real GPS, map routing, driver-customer dispatch, OTP, payments, or live Firebase connection is implemented. Firebase packages and starter security rules are included, but credentials and backend deployment are not configured. Do not use for real rides or payments.
