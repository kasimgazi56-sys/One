# ONE RIDE — Flutter demo

A cross-platform Flutter starter demo for an Aligarh bike-taxi booking app.

## Included
- ONE RIDE yellow/black branding
- Customer home screen
- Pickup and destination text fields
- Clearly-labelled demo fare estimate (not distance-based)
- Simulated booking confirmation
- My Rides screen
- Profile screen
- Android and iOS Flutter project structure

## Run locally
1. Install Flutter SDK and Android Studio (for Android) / Xcode on macOS (for iOS).
2. Unzip this folder.
3. In this folder run:
   ```bash
   flutter pub get
   flutter run
   ```
4. To create an Android APK:
   ```bash
   flutter build apk --debug
   ```
5. To build for iPhone, use macOS with Xcode:
   ```bash
   flutter build ios
   ```

## Important limitations
This is a UI/interaction demo, not a live taxi service. It does not contact drivers or provide real GPS, maps, phone authentication, payment processing, notifications, or an admin backend. The fare is intentionally a placeholder. Do not use it for real rides or collect customer payments.

## Next development phase
- Confirm business model, operating area, driver onboarding and applicable local/state permits.
- Add Firebase Authentication and Firestore with secure server-side rules.
- Add Google Maps/Places and real route-distance fare calculation.
- Build a separate driver app and dispatch/matching backend.
- Add verified driver documents, emergency support, trip sharing and incident handling.
- Integrate a compliant payment provider and test refunds/settlement.
- Complete privacy policy, terms, data safety disclosures, app-store testing and release setup.
